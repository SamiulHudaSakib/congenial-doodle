-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2019 at 06:22 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `info`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(20) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `phone_number` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_name`, `phone_number`, `email`, `password`) VALUES
(1, 'Samiul', '01111111111', 'samiul@gmail.com', '6546'),
(2, 'Huda', '1222222222', 'huda@gmail.com', '995846'),
(3, 'Akib', '01766558479', 'akib@yahoo.com', 'sA85858585'),
(4, 'Arnob', '025864897541', 'arnob@yahoo.com', 'Af898989898'),
(5, 'Mahbub', '01454545859', 'mahbub@yahoo.com', 'Sk45858585'),
(6, 'Aftab', '01456565656', 'aftab@gmail.com', 'Af78787878'),
(7, 'Refat', '01555448889', 'refat@gmail.com', 'Re45658578'),
(8, 'Hossain', '01758965874', 'hossain@outlook.com', 'Abc789456'),
(9, 'Samiul Huda', '01766569407', 'samiul@outlook.com', 'Samiul12345'),
(10, 'Wahid', '01456879547', 'wahid@gmail.com', 'Wahid12345'),
(11, 'Bishal', '01856595874', 'bishal@gmail.com', 'Bishal1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
